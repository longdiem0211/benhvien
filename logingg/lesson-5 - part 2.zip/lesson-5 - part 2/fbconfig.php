<?php

$fb = new Facebook\Facebook([
    'app_id' => 'xxxxxxxxxxxxxxxx', // Thay thông tin app của bạn vào đây
    'app_secret' => 'xxxxxxxxxxxxxxxxxxxxxxxx',
    'default_graph_version' => 'v3.0',
        ]);
?>

